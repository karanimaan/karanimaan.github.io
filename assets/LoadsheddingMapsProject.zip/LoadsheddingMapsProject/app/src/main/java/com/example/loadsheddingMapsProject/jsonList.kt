package com.example.loadsheddingMapsProject

import org.json.JSONObject

class jsonList {

    fun main() {
        val json = """
        {
            "areas": [
                {
                    "id": "eskde-10-fourwayswestcityofjohannesburggauteng",
                    "name": "Fourways-WEST (10)",
                    "region": "Eskom Direct, City of Johannesburg, Gauteng"
                },
                {
                    "id": "eskde-14-fourwaysext14eastcityofjohannesburggauteng",
                    "name": "Fourways Ext 14-EAST (14)",
                    "region": "Eskom Direct, City of Johannesburg, Gauteng"
                },
                ...
            ]
        }
    """.trimIndent()

        val jsonObject = JSONObject(json)
        val areasArray = jsonObject.getJSONArray("areas")

        val areasList = mutableListOf<String>()

        for (i in 0 until areasArray.length()) {
            val areaObject = areasArray.getJSONObject(i)
            val areaName = areaObject.getString("name")
            areasList.add(areaName)
        }

        // Now you can use the `areasList` as per your requirement
        for (area in areasList) {
            println(area)
        }
    }

}