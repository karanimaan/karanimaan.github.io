package com.example.loadsheddingMapsProject

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.loadsheddingMapsProject.ui.theme.EditTextProjectTheme
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException

private val client = OkHttpClient()

// global variables to be mutated after the relevant API calls (in checkIfInLoadshedding function)
// (This may be error prone, so the observer pattern is recommended rather)
private var areaID = ""
private var areasWithLoadShedding = listOf<String>()


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            EditTextProjectTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MyColumn()
                }
            }
        }
    }
}


fun onSearchButtonClick() {
    // using hardcoded areas in Cape Town
    // functions to be implemented and replace hardcoded lines

    // TODO: get addressFrom from textbox
    val addressFrom = "Access Park"

    // TODO: get addressTo from 2nd textbox
    val addressTo = "Forest Hill Residence"

    // get route
    // get areas on route
    // using Maps API
    val areasNames = listOf("Claremont, Cape Town", "Rondebosch, Cape Town")


    for (areaName in areasNames) {
        checkIfInLoadshedding(areaName)
    }

    // TODO: wait for requests to finish


    if (areasWithLoadShedding.isEmpty()) {
        println("Route is good")
    } else {
        println("$areasWithLoadShedding have loadshedding. Find another route avoiding these areas")
        // TODO: Add implementation to change route

    }
}


fun checkIfInLoadshedding(areaName: String) {
    val url = "https://developer.sepush.co.za/business/2.0/areas_search?text=$areaName"
    val request = Request.Builder()
        .url(url)
        .addHeader("token", "A2DFACF6-81AA406C-BBCC6F26-D0D5E79E")
        .build()

    // Add request to queue
    client.newCall(request).enqueue(object : Callback {
        override fun onFailure(call: Call, e: IOException) {
            e.printStackTrace()
        }

        override fun onResponse(call: Call, response: Response) {
            response.use {
                if (!response.isSuccessful) throw IOException("Unexpected code $response")

                val json = JSONObject(response.body!!.string())

                // TODO: using index 0 for getJSONObject does not necessarily give the correct area.
                //  Must find correct index
                areaID = json.getJSONArray("areas").getJSONObject(0).get("id") as String
                makeAreaInfoRequest(areaID, areaName)
            }
        }
    })
}


fun makeAreaInfoRequest(areaID: String, areaName: String) {
    val url = "https://developer.sepush.co.za/business/2.0/area?id=$areaID&test=current"
    val request = Request.Builder()
        .url(url)
        .addHeader("token", "A2DFACF6-81AA406C-BBCC6F26-D0D5E79E")
        .build()

    client.newCall(request).enqueue(object : Callback {
        override fun onFailure(call: Call, e: IOException) {
            e.printStackTrace()
        }

        override fun onResponse(call: Call, response: Response) {
            response.use {
                if (!response.isSuccessful) throw IOException("Unexpected code $response")

                val json = JSONObject(response.body!!.string())
                println(json)

/*
                 TODO:
                 get loadshedding times
                 if currentTime in loadshedding times
                  then areasWithLoadShedding.append(areaName)
*/

            }
        }
    })
}



@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyColumn(modifier: Modifier = Modifier) {

    var text1 by rememberSaveable { mutableStateOf("Text") }
    var text2 by rememberSaveable { mutableStateOf("Text") }

    Column(verticalArrangement = Arrangement.Top, modifier = modifier.padding(end = 30.dp)) {
        // Text fields for addresses
        TextField(
            value = text1,
            onValueChange = {
                text1 = it
            },
            label = { Text("From") },
            placeholder = { Text(text = "fourways") }   // Not showing in GUI. Not sure why
        )
        TextField(
            value = text2,
            onValueChange = {
                text2 = it
            },
            label = { Text("To") }
            )

        // Search Button
        Button(onClick = { onSearchButtonClick() }) {
            Text(text = "search")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun MyColumnPreview() {
    EditTextProjectTheme {
        MyColumn()
    }
}
